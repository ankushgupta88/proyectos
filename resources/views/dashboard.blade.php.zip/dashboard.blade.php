@extends('layouts.sidebar')
@section('content')
<div class="col-sm-8">
<h3>Dahboard</h3>
@if(Session::get('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
{{Session::get('error')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<div class="form-group">

</div>
@endsection