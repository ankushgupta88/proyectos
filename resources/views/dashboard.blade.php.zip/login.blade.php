@extends('layouts.default')
@section('content')
<div class="col-sm-8">
<h3>Login</h3>
@if(Session::get('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
{{Session::get('error')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<form action="<?php echo url('loginUser')?>" method="post">
@csrf
<div class="form-group">
<label>Email</label>
<input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Enter Email" >
</div>
@error('email')
<div class="alert alert-danger">{{ $message }}</div>
@enderror
<div class="form-group">
<label>Password</label>
<input type="password" name="password" class="form-control" placeholder="Enter Password" >
</div>
@error('password')
<div class="alert alert-danger">{{ $message }}</div>
@enderror
<div class="form-group">
<label>Select Role</label>
<select id="role" name="role" class="form-control">
    <option value="0">Student</option>
    <option value="1">Tutor</option>
 </select>
</div>
<button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
@endsection